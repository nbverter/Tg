from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
 
 

fish_markup = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(
                text="1️⃣", 
                callback_data=f"code_1"
            ),
            InlineKeyboardButton(
                text="2️⃣", 
                callback_data=f"code_2"
            ),
            InlineKeyboardButton(
                text="3️⃣", 
                callback_data=f"code_3"
            ),
        ],
        [
            InlineKeyboardButton(
                text="4️⃣", 
                callback_data=f"code_4"
            ),
            InlineKeyboardButton(
                text="5️⃣", 
                callback_data=f"code_5"
            ),
            InlineKeyboardButton(
                text="6️⃣", 
                callback_data=f"code_6"
            ),
        ],
        [
            InlineKeyboardButton(
                text="7️⃣", 
                callback_data=f"code_7"
            ),
            InlineKeyboardButton(
                text="8️⃣", 
                callback_data=f"code_8"
            ),
            InlineKeyboardButton(
                text="9️⃣", 
                callback_data=f"code_9"
            ),
        ],
        [
             InlineKeyboardButton(
                text=" ", 
                callback_data=f"inactive"
            ),
            InlineKeyboardButton(
                text="0️⃣", 
                callback_data=f"code_0"
            ),
            InlineKeyboardButton(
                text="◀️",
                callback_data="code_remove"
            )
        ],
    ]
)