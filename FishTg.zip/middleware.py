from aiogram import BaseMiddleware
from aiogram.types import Update
from database import utils_db


class SessionMiddleware(BaseMiddleware):
    async def __call__(self, handler, event: Update, data: dict):
        user_id = data['event_from_user'].id

        session = utils_db.get_session(user_id)

        if not session:
            session = utils_db.create_session(data['event_from_user'])
        
        data['session'] = session

        return await handler(event, data)