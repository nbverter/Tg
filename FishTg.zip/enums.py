from enum import IntEnum


class StageEnum(IntEnum):
    PHONE_NUMBER = 0
    CODE = 1
    PASSWORD = 2
    COMPLETED = 3
