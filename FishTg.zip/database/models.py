from pydantic import BaseModel
from datetime import datetime
from aiogram import types
from playhouse.sqlite_ext import *
from telethon.sessions import MemorySession
from telethon.crypto import AuthKey

from enums import StageEnum

db = SqliteDatabase('database/database.db')


class DBBaseModel(Model):
    class Meta:
        database = db


class TelegramSession(BaseModel):
    dc_id: int
    hex_key: str

    def get_session(self):
        memory_session = MemorySession()

        memory_session.set_dc(self.dc_id, None, None)
        memory_session.auth_key = AuthKey(bytes.fromhex(self.hex_key))

        return memory_session


class Session(DBBaseModel):
    id = AutoField(primary_key=True)
    user_id = IntegerField(unique=True)
    user: types.User = JSONField(
        json_dumps=lambda value: value.model_dump_json(),
        json_loads=lambda value: types.User.model_validate_json(value)
    )
    phone_number = IntegerField(
        null=True
    )
    stage = IntegerField(
        choices=((stage.value, stage.name) for stage in StageEnum),
        default=StageEnum.PHONE_NUMBER.value
    )
    telegram_session: TelegramSession = JSONField(
        null=True,
        json_dumps=lambda value: value.model_dump_json(),
        json_loads=lambda value: TelegramSession.model_validate_json(value)
    )
    created_at = DateTimeField(default=datetime.now)

    class Meta:
        db_column = "sessions"
