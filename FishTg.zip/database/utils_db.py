from database.models import Session, db
from aiogram.types import User


def create_session(user: User) -> Session:
    return Session.create(
        user_id=user.id,
        user=user
    )


def get_session(user_id: int) -> Session | None:
    return Session.get_or_none(user_id=user_id)


def update_session(session: Session, **kwargs):
    return session.update(**kwargs)


def create_table():
    db.create_tables([Session])
    